package demo.demo_ecommerce.config;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class JwtAuthConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private static final String REALM_ACCESS = "realm_access";
    private static final String RESOURCE_ACCESS = "resource_access";
    private static final String ROLES_KEY = "roles";
    private static final String CLIENT_ID = "ClientPSW"; // Modifica con il tuo client-id di Keycloak

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        Set<SimpleGrantedAuthority> roles = new HashSet<>();

        // Estrarre i ruoli da realm_access
        Map<String, Object> realmAccess = jwt.getClaimAsMap(REALM_ACCESS);
        if (realmAccess != null && realmAccess.containsKey(ROLES_KEY)) {
            List<String> realmRoles = (List<String>) realmAccess.get(ROLES_KEY);
            roles.addAll(realmRoles.stream()
                    .map(role -> "ROLE_" + role) // Aggiunge il prefisso ROLE_
                    .map(SimpleGrantedAuthority::new)
                    .toList());
        }

        // Estrarre i ruoli da resource_access (Client-specific roles)
        Map<String, Object> resourceAccess = jwt.getClaimAsMap(RESOURCE_ACCESS);
        if (resourceAccess != null && resourceAccess.containsKey(CLIENT_ID)) {
            Map<String, Object> clientRoles = (Map<String, Object>) resourceAccess.get(CLIENT_ID);
            if (clientRoles.containsKey(ROLES_KEY)) {
                List<String> resourceRoles = (List<String>) clientRoles.get(ROLES_KEY);
                roles.addAll(resourceRoles.stream()
                        .map(role -> "ROLE_" + role) // Aggiunge il prefisso ROLE_
                        .map(SimpleGrantedAuthority::new)
                        .toList());
            }
        }

        return new JwtAuthenticationToken(jwt, roles);
    }
}

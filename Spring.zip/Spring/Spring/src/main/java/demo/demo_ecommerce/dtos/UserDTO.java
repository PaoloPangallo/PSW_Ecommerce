package demo.demo_ecommerce.dtos;

import demo.demo_ecommerce.entities.Role;
import demo.demo_ecommerce.entities.Wishlist;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
public class UserDTO {

    @NotBlank
    private String username;


    @NotBlank
    @Size(min = 8, message = "Password must be at least 8 characters long")
    private String password;


    @Email(message = "Email should be valid")
    @NotBlank
    private String email;


    @NotBlank
    private Role role;



}

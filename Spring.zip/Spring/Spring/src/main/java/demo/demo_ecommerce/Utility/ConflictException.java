package demo.demo_ecommerce.Utility;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}


package demo.demo_ecommerce.Utility;

import demo.demo_ecommerce.entities.Product;
import demo.demo_ecommerce.entities.User;
import demo.demo_ecommerce.repositories.ProductRepository;
import demo.demo_ecommerce.repositories.UsersRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
/*
@Component
public class DataInitializer implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final UsersRepository userRepository;

    public DataInitializer(ProductRepository productRepository, UsersRepository userRepository) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Aggiunta di prodotti
        Product product1 = new Product();
        product1.setName("Laptop");
        product1.setDescription("High-end gaming laptop");
        product1.setPrice(1500.0);
        product1.setStock(10);

        Product product2 = new Product();
        product2.setName("Smartphone");
        product2.setDescription("Latest model smartphone with great features");
        product2.setPrice(999.99);
        product2.setStock(20);

        Product product3 = new Product();
        product3.setName("Wireless Headphones");
        product3.setDescription("Noise-cancelling headphones with premium sound quality");
        product3.setPrice(199.99);
        product3.setStock(30);

        productRepository.save(product1);
        productRepository.save(product2);
        productRepository.save(product3);

        // Aggiunta di utenti
        User user1 = new User();
        user1.setUsername("john_doe");
        user1.setEmail("john.doe@example.com");
        user1.setPassword("password123");

        User user2 = new User();
        user2.setUsername("jane_smith");
        user2.setEmail("jane.smith@example.com");
        user2.setPassword("securepass");

        userRepository.save(user1);
        userRepository.save(user2);

        // Log per verificare i dati inseriti
        System.out.println("Dati inizializzati con successo!");
        System.out.println("Prodotti inseriti:");
        productRepository.findAll().forEach(System.out::println);
        System.out.println("Utenti inseriti:");
        userRepository.findAll().forEach(System.out::println);
    }
}
*/
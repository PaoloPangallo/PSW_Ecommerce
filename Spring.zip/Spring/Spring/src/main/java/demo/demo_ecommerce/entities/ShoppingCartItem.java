package demo.demo_ecommerce.entities;


import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.*;

@Entity
@Table(name = "shopping_cart_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShoppingCartItem {
    @ManyToOne(optional = false)
    @JoinColumn(name = "cart_id", nullable = false, unique = true)
    private Cart cart;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;  // Prodotto selezionato

    @Min(1)
    private Integer quantity;  // Quantità del prodotto selezionata

}

package demo.demo_ecommerce.config;


import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/roles")
public class RoleController {

    // Endpoint per ADMIN
    @GetMapping("/admin")
    @PreAuthorize("hasRole('admin')")
    public String adminAccess() {
        return "Accesso riservato agli ADMIN.";
    }

    // Endpoint per MANAGER
    @GetMapping("/manager")
    @PreAuthorize("hasRole('manager')")
    public String managerAccess() {
        return "Accesso riservato ai MANAGER.";
    }

    // Endpoint per USER
    @GetMapping("/user")
    @PreAuthorize("hasRole('client_user')")
    public String userAccess() {
        return "Accesso riservato agli utenti USER.";
    }
}


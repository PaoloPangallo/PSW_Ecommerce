package demo.demo_ecommerce.services;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import demo.demo_ecommerce.entities.Product;
import demo.demo_ecommerce.repositories.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import demo.demo_ecommerce.entities.Cart;
import demo.demo_ecommerce.entities.Order;
import demo.demo_ecommerce.entities.User;
import demo.demo_ecommerce.repositories.CartRepository;
import demo.demo_ecommerce.repositories.OrderRepository;
import demo.demo_ecommerce.repositories.UsersRepository;

@Service
public class OrderService {

    private ProductRepository productRepository;
    Product product;
    Pageable pageable;


    private final OrderRepository orderRepository;
    private final UsersRepository userRepository;
    private final CartRepository cartRepository;

    public OrderService(OrderRepository orderRepository, UsersRepository userRepository,
                        CartRepository cartRepository) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.cartRepository = cartRepository;
    }

    // Metodo per creare un nuovo ordine
    @Transactional
    public Order createOrder(Long userId) {
        // Controlla se l'utente esiste
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Utente non trovato"));

        // Recupera il carrello dell'utente
        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new IllegalArgumentException("Carrello non trovato per l'utente"));

        // Controlla che il carrello non sia vuoto
        if (cart.getItems().isEmpty()) {
            throw new IllegalArgumentException("Il carrello è vuoto, non è possibile creare un ordine");
        }

        // Calcola il totale dell'ordine
        double total = cart.getItems().entrySet().stream()
                .map(entry -> {
                    Long productId = entry.getKey();
                    int quantity = entry.getValue();
                    BigDecimal price = getProductPriceById(productId); // Metodo helper

                    // Converti `quantity` in BigDecimal e moltiplica con il prezzo
                    return price.multiply(BigDecimal.valueOf(quantity));
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add) // Somma i totali
                .doubleValue(); // Converti il totale finale in double


        // Verifica che il totale sia positivo
        if (total <= 0) {
            throw new IllegalArgumentException("Il totale dell'ordine deve essere maggiore di zero");
        }

        // Crea il nuovo ordine
        Order order = new Order();
        order.setUser(user);
        order.setTotal(BigDecimal.valueOf(total));
        order.setCreatedAt(LocalDateTime.now());

        // Salva l'ordine nel database
        order = orderRepository.save(order);

        // Pulisci il carrello
        cart.getItems().clear();
        cartRepository.save(cart);

        return order;
    }

    // Metodo per ottenere tutti gli ordini di un utente
    public Page<Order> getOrdersByUserId(Long userId) {

        return orderRepository.findByUserId(userId, pageable);
    }

    // Metodo per ottenere i dettagli di un singolo ordine
    public Order getOrderById(Long userId, Long orderId) {
        return orderRepository.findByIdAndUserId(orderId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Ordine non trovato"));
    }

    // Metodo helper per ottenere il prezzo di un prodotto (esempio di mock, puoi sostituirlo con una chiamata al repository dei prodotti)
    private BigDecimal getProductPriceById(Long productId) {
        return productRepository.findById(productId)
                .map(Product::getPrice)
                .orElseThrow(() -> new IllegalArgumentException("Prodotto non trovato con ID: " + productId));
    }

}

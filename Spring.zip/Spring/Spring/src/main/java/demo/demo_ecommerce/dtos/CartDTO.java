package demo.demo_ecommerce.dtos;

import demo.demo_ecommerce.entities.Cart;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;

import java.util.Map;

@Getter
public class CartDTO {

    @NotNull
    private final Long id;

    @NotNull
    private final Map<Long, Integer> items;

    public CartDTO(Long id, Map<Long, Integer> items) {
        this.id = id;
        this.items = items;
    }

    public static CartDTO fromEntity(Cart cart) {
        return new CartDTO(cart.getId(), cart.getItems());
    }
}

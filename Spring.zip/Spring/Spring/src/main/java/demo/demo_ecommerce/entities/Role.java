package demo.demo_ecommerce.entities;


public enum Role {
    USER,
    ADMIN
}


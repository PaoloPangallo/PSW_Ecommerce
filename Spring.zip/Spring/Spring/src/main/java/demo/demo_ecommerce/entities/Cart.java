package demo.demo_ecommerce.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

@Getter
@Entity
@Setter
public class Cart {

    private static final Logger logger = LoggerFactory.getLogger(Cart.class);

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(mappedBy = "cart")
    private User user;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "cart_items", joinColumns = @JoinColumn(name = "cart_id"))
    @MapKeyColumn(name = "product_id")
    @Column(name = "quantity")
    private Map<Long, Integer> items = new HashMap<>();

    public Cart() {
    }

    public Cart(User user) {
        this.user = user;
    }



    public void addItem(Long productId, int quantity) {
        if (productId == null || quantity <= 0) {
            throw new IllegalArgumentException("Product ID cannot be null and quantity must be greater than zero.");
        }
        int newQuantity = items.getOrDefault(productId, 0) + quantity;
        if (newQuantity > 0) {
            items.put(productId, newQuantity);
            logger.info("Added product {} with quantity {} to cart {}", productId, quantity, id);
        } else {
            items.remove(productId);
            logger.info("Removed product {} from cart {}", productId, id);
        }
    }

    public void removeItem(Long productId) {
        items.remove(productId);
        logger.info("Removed product {} from cart {}", productId, id);
    }

    public void clear() {
        items.clear();
        logger.info("Cleared all items from cart {}", id);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cart cart = (Cart) o;
        return id != null && id.equals(cart.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}

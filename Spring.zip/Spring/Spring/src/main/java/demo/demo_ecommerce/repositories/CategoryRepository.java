package demo.demo_ecommerce.repositories;

import demo.demo_ecommerce.entities.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    // Puoi aggiungere metodi personalizzati qui se necessario
}
